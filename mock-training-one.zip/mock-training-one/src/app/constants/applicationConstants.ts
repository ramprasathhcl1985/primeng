import { ITableHeaders } from '../models/model';
export class ApplicationConstants {

    public static mobileValidationPattern = '^((\\+91-?)|0)?[0-9]{10}$';
    public static defaultAccountType = '1';
    public static basePath  = 'http://10.117.214.149:8081/';
    public static registerationBasePath  = 'http://10.117.214.87:8081/';
    public static registerationEndpoint  = 'retailbanking/customers';
    public static loginBasePath  = 'http://10.117.214.87:8081/';
    public static loginEndpoint  = 'retailbanking/customers/login';
    public static usersList  = 'users';
    public static accountDetails  = 'retailbanking/accounts/accountsummary';
    public static accountTransactions  = 'account-transactions';
    public static contentTYpe = 'application/json';
    public static userLoginId = 'USER-LOGIN-ID';
    public static groupsList  = 'groups';
    public static userGroupsList  = 'user-groups';
    public static messageList  = 'messages';
    public static joinGroupMessage  = 'Are you sure want to join this group?';
    public static loginErrorMessage = 'Please enter valid login details';
    public static userfullName = 'USER-FULL-NAME';
    public static beneficaryList  = 'retailbanking/accounts';
    public static addPayeeURL  = 'retailbanking/transactions/fund-transfer';
    public static userAccountNo = 'USER-ACCOUNT-NO';
    public static monthlyTransaction = 'retailbanking/transactions/monthly';


    /* form static datas */
    public static confirmPasswordInput = 'userConfirmPassword';
    public static passwordInput = 'userPassword';

    /* table header for account details*/
    public static accountDetailsHeaders: string[] = ['Name', 'Account No', 'Balance'];
    public static transactionHeaders: string[] = ['Transaction ID ', 'Transaction Date', 'Transaction Amount', 'Transaction Type', 'Transaction Description'];

    public static monthsList: string[] =  [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ];




}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { HeaderService } from '../../layout-module/header/services/header.service';
import { UserApiService } from '../services/user-api.service';
import { IUsers, IUserLogin, } from '../../../models/model';
import { ApplicationConstants } from '../../../constants/applicationConstants';


@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  public userLogin: FormGroup;
  public usersList: IUsers[];
  public invalidLogin = false;

  public inValidUserMessage = '';

  public userName = new FormControl('', [Validators.required]);
  public userPassword = new FormControl('', [Validators.required]);


  constructor(private fb: FormBuilder, private router: Router, private headerService: HeaderService, private userService: UserApiService) {
    this.userLogin = this.fb.group({
      userName: this.userName,
      userPassword: this.userPassword
    });
  }

  ngOnInit() {
  }

  /* to redirect to register page*/
  public goToRegister(): void {
    this.router.navigateByUrl('user/register');
  }

  /* form submit checking suer login is present in the user List */
  public onSubmit(): void {
    if (this.userLogin.valid) {
      const userLogin: IUserLogin = {
        userName: this.userName.value,
        password: this.userPassword.value,


      };

      this.userService.loginUser(userLogin).subscribe((data: any) => {

        if (data.statusCode == 406) {

          this.invalidLogin = true;

        } else {
        this.userService.setSessionItem(ApplicationConstants.userLoginId, data.customerId.toString());

        this.router.navigateByUrl('/customer');
        }

      }, (error) => {
        this.invalidLogin = true;

      }

      );




    } else {
      Object.keys(this.userLogin.controls).forEach(key => {
        this.userLogin.controls[key].markAsDirty();
      });
    }

  }




}

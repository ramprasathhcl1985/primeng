export class IUsers {
    id?: number;
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    mobileNo: string;
    address: string;
    emailId: string;
    accountType?: string;
    userName: string;
    password: string;

}
export class IUserLogin {
    id?: number;
    userName: string;
    password: string;
}

export class ITableHeaders {
    columnName: string;

}

export class IAccountDetails {
    id?: number;
    account_no: number;
    balance: number;
    account_satus: string;
    account_type: string;
    customerId: number;

}

export class IAccountDetailBody {
    name: string;
    accountNumber: number;
    balance: number;
 }

export class ITransactionDetails {
    transactionType: string;
    transactionAmount: Number;
    transactionDescription: string;
    transactionId: Number;
    toAccount?: Number;
    fromAccount?: Number;
    transactionDate: string;

 }

export class IBeneficiary {
    id?: number;
    accountNumber: string[];
    message: string;
    statusCode: number;
    transferAccounts?: string[];
 }
export class IpaymentTransaction {
    id?: number;
    transactionAmount: Number;
    transactionDescription: string;
    fromAccount: string;
    toAccount: string;
    transactionDate?: string;

 }

export class IResponseBlock {
    statusCode?: number;
     message?: string;
     customerId?: number;

 }
export class IMonthlyReport {
    transactionId?: number;
    transationType: string;
    transactionAmount: number;
    transactionDetails: string;
    beneficiaryId: number;
    accountId: number;
    date: string;
 }
export class IMonthlyInput {
    accountNumber?: string;
    month: number;
    year: number;

 }


import { Component, OnInit } from '@angular/core';
import { UserApiService } from '../../common-modules/users-module/services/user-api.service';
import { IAccountDetails, IAccountDetailBody, ITransactionDetails } from '../../models/model';
import { ApplicationConstants } from '../../constants/applicationConstants';
import { HeaderService } from '../../common-modules/layout-module/header/services/header.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public accountDetails: IAccountDetails;
  public userId: string;
  public accountDetailsHeaders: string[];
  public accountDetailsData: IAccountDetailBody[] = [];
  public transactionList: ITransactionDetails[];
  public tableHeaders: string[];


  constructor(private router: Router, private userService: UserApiService, private headerService: HeaderService) {
    this.accountDetailsHeaders = ApplicationConstants.accountDetailsHeaders;

    this.tableHeaders = ApplicationConstants.transactionHeaders;

  }

  ngOnInit() {
    if (sessionStorage.getItem(ApplicationConstants.userLoginId)) {
      this.userId = sessionStorage.getItem(ApplicationConstants.userLoginId);
      this.headerService.enableMenus.next(true);
    } else {
      this.userId = '0';
      this.router.navigateByUrl('/login');
    }


    this.userService.getUserAccountDetails(this.userId).subscribe((data) => {

      const accountDetail: IAccountDetailBody = {
        name: data.name,
        accountNumber: data.accountNumber,
        balance: data.balance
      };
      this.headerService.loginUserName.next(data.name);
      sessionStorage.setItem(ApplicationConstants.userfullName, data.name);
      sessionStorage.setItem(ApplicationConstants.userAccountNo, data.accountNumber);

      this.accountDetailsData.push(accountDetail);

      this.transactionList = data.transactions;




    });




  }





}
